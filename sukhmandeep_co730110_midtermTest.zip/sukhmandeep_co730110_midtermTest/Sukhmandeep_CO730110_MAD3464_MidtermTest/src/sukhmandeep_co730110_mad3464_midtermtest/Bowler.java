package sukhmandeep_co730110_mad3464_midtermtest;


import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class Bowler extends Player {
      int noOversThrown;
      int noRunsGiven;
      int noWicketTaken;
      int runsPerOver;
      int runsPerWicket;
      int bowlingPoints;
      
       Scanner input = new Scanner(System.in);
      Bowler(){
          super();
          this.noOversThrown = 0;
          this.noRunsGiven = 0;
          this.noWicketTaken = 0;
          this.runsPerOver =0;
          this.runsPerWicket = 0;
          this.bowlingPoints = 0;
          
          
      }
      Bowler(int noOversThrown,int noRunsGiven, int noWicketTaken, int runsPerOver,int runsPerWicket,int bowlingPoints ,
              String PlayerId, String PlayerName){
          super(PlayerId,PlayerName);
          this.noOversThrown = noOversThrown;
          this.noRunsGiven = noRunsGiven;
          this.noWicketTaken = noWicketTaken;
          this.runsPerOver = runsPerOver;
          this.runsPerWicket = runsPerWicket;
          this.bowlingPoints = bowlingPoints;
          
          
      }
      void readData(){
          
          super.readData();
          System.out.println("Enter no of overs:");
          this.noOversThrown = input.nextInt();
          System.out.println("Enter no of runs given:");
          this.noRunsGiven = input.nextInt();
          System.out.println("enter no if wickets:");
          this.noWicketTaken = input.nextInt();
      }
      void displayData(){
          super.displayData();
          System.out.println("no of overs thrown:" + this.noOversThrown + "\n no of runs:" +this.noRunsGiven  + "\n no of wickets: " + this.noWicketTaken);
         System.out.println(" no of runs per over: " + this.runsPerOver + "\n runs per wicket: " + this.runsPerWicket + "\n bowling points: " + this.bowlingPoints);
          
      }
      
      void calAvg(){
          this.runsPerOver = noRunsGiven/noOversThrown;
          this.runsPerWicket = noRunsGiven/noWicketTaken;
          
      }
      
      void calPoints(){
          int points;
          int pointPerWicket = 5*noWicketTaken;
          int pointPerRun = 0;
          if(noRunsGiven<=3){
              pointPerWicket = 10;
          }
          else
          {
              pointPerWicket = 5;
          }
      points = pointPerWicket + pointPerRun;
      this.bowlingPoints = points;
      }
}   
      
            

