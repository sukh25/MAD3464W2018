package sukhmandeep_co730110_mad3464_midtermtest;


import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class Player {
    String PlayerId;
  String PlayerName;  
  String PlayerType;
    Scanner input = new Scanner(System.in);
  Player(){
      this.PlayerId = "";
      this.PlayerName = "";
      
}
  Player(String PlayerId,String PlayerName){
      this.PlayerId = PlayerId;
      this.PlayerName = PlayerName;
            
  }
  
  void readData(){
      System.out.println("enter id is:"  + this.PlayerId);
      this.PlayerId = input.nextLine();
      System.out.println("enter Player name: " +this.PlayerName);
      this.PlayerName = input.nextLine();
}
void displayData(){
     System.out.println(" id is:"  + this.PlayerId);
      System.err.println(" Player name: " +this.PlayerName);
}
String type(){
     System.out.println("player is bowler or batsman:" );
     this.PlayerType  = input.nextLine();
return PlayerType;
}}