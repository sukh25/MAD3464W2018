/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sukhmandeep.__co730110_mad3464_midtermtest;

/**
 *
 * @author macstudent
 */
public class Sukhmandeep__co730110_MAD3464_MidtermTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
       Encryption enc = new Encryption();
       enc .encryption("ZANIL");


    }}

        
    
    

