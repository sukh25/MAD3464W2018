/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day.pkg2;

import static java.lang.System.out;
import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Day2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
       bank yourbank = new bank();
        bank mybank = new bank();

System.out.println("bank id : " + mybank.bankID);
System.out.println("bank name : " + mybank.bankName);
 
mybank.getBankName();


yourbank.setBankName("icici");
yourbank.getBankName();


Scanner myInput = new Scanner(System.in);
String name;

System.out.println("enter bank name:");
name = myInput.nextLine();

yourbank.setBankName(name);
yourbank.getBankName();



arithmetic operation1 = new arithmetic();

System.out.println("output of integer addition : " +operation1.addition(1,20));

System.out.println("output of float : " +operation1.addition(18.2f,743.34f));

System.out.println("output of mult: " +operation1.multiplication(10,20,30));



arithmetic.multiplication(20,30);

arithmetic.n1 = 29;
//arithmetic.n2 = 20;
System.out.println(arithmetic.n1 +  " " + arithmetic.n2);
    }
    
}
