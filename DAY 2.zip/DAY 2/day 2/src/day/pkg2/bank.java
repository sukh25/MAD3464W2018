/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day.pkg2;

/**
 *
 * @author macstudent
 */

public class bank {
    int bankID = 10120;
    String bankName = "TD";
 
    void getBankName(){
        System.out.println(" bank name : " + bankName);
    }
    
    void setBankName(String name){
        this.bankName = name;
    }
}