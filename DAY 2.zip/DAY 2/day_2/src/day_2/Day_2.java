/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day_2;

/**
 *
 * @author macstudent
 */
public class Day_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

          person one = new person();
      //   one.displayData();
        person sukhman = new person("sukhman", "randhawa", 24);
    //    sukhman.displayData();
        
        person sukh = new person(sukhman);
       // sukh.displayData();

        
        
//        Employee e1 = new Employee(1356.45);
//        e1.display();
        
        
        Employee e2  = new Employee();
        e2.display();
        e2.firstName = "sukh";
        e2.lastName = "randhawa";
        e2.age = 24;
        e2.salary = 32442.34;
        
      //  e2.displayData();
        e2.display();
                
        
        //method overriding, when subclass method is called,it will override method of super class
        
        
        Employee e3 = new Employee();
        e3.read();
        e3.display();
        
        
        
////        System.out.println("last name: "+ e2.lastName);
    }

}
