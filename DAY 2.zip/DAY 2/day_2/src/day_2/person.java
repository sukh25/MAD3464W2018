/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day_2;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class person {
    
    String firstName;
    String lastName;
    int age;
    
   person(){
       this.firstName = "unknown";
       this.lastName = "unknown";
       this.age = 1;
       
   } 
    person(String fnm,String Lnm, int age){
    this.firstName = fnm;
    this.lastName = Lnm;
    this.age = age;
    
    }
    person(person object){
         this.firstName = object.firstName;
         this.lastName = object.lastName;
         this.age = object.age;
    }
    
    void read(){
 Scanner input = new Scanner(System.in);
 
 System.out.println("enter first name: ");
 this.firstName = input.nextLine();
 
 
 System.out.println("enter last name: ");
 this.lastName = input.nextLine();
 
 System.out.println("enter age: ");
 this.age = input.nextInt();
    }
     void display(){
         
        System.out.println("enter last name: " + this.firstName);  
          System.out.println("enter last name: " + this.lastName);
           System.out.println("enter age: " + this.age);
}
}