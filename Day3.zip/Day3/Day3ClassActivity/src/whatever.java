
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author souravdewett
 */


public class whatever {
    public static void main(String[] args)
    {
       ReadPersonInfo read = new ReadPersonInfo();
       read.readData();
       read.DisplayData();
       
       Employee emp = new Employee();
       emp.readData();
       emp.DisplayData();
    
       //faculty per = new faculty();
       //per.DisplayData();
    }
}
interface Person {
        void  readData();
        void DisplayData();
}

class ReadPersonInfo implements Person
{
 String Name;
 int age;   
    @Override
            public void readData()
            {
                
                Scanner sc = new Scanner(System.in);
                System.out.print("Enter Person's Name");
                Name = sc.nextLine();
    
                System.out.println("Enter Person's Age");
                age = sc.nextInt();
            }
            
    @Override 
            public void DisplayData()
            {
                System.out.println("Person's name is :"+Name);
                System.out.println("Person's age is :" +age);
            }
    
    
}
interface employeeinformation
{
    void readData();
    void DisplayData();
}
class Employee implements employeeinformation {
    String type;
    double salary;
    
    Scanner sc = new Scanner(System.in);
    @Override
    public void readData()
    {
        System.out.println("enter Work type:");
        type = sc.nextLine();
        
        System.out.println("Enter your salary:");
        salary = sc.nextInt();
    }
    
    @Override
    public void DisplayData()
    {
        System.out.println("The Work type is :" +type);
        System.out.println("Employee salary is : "+salary);
    }

    class faculty extends ReadPersonInfo implements Person,employeeinformation
    {
        String course;
        
        @Override
        public void readData()
        {
            System.out.println("Enter Course Name :");
            course = sc.nextLine();
            
        }
        
        @Override 
        public void DisplayData()
        {
            System.out.println("Name of the person is :"+Name);
            System.out.println("Age if the person is :"+age);
            System.out.println("The Work type is :" +type);   
            System.out.println("Employee salary is : "+salary);
            System.out.println("Enter Course Name :"+course);
        }
        
    }
}
