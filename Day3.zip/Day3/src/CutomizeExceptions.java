/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author souravdewett
 */
class testException extends Exception
{
    public testException(String message) //constructor that gives message when exception is generated
    {
        super(message);         //exception is the suuper class
    }
}

public class CutomizeExceptions {
    public static void main(String[] args) throws Exception
    {
        int n1 = 10;
        try
        {
            if(n1 == 10)
            {
                throw new testException("Test unsuccessful");
            }
        }
            catch(testException e)
                    {
                    System.out.println("customized Exception");
                    System.out.println(e.getMessage());
                    System.out.println(e.getStackTrace());
                    }
        }
    }

