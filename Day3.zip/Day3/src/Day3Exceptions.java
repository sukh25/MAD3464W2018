/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author souravdewett
 */
public class Day3Exceptions 
{
    public static void main(String[] args)
    {
        int n1=10,n2=2;
        int array[] = {10,20,30};
        try
        {
            if(n2==0)
            {
                throw new ArithmeticException();
            }
            else
            {
            n1= n1/n2;
            }
            
            n2 = array[6];
            System.out.println("Value of n2 is:"+n2);
        } 
        
        
        catch(ArithmeticException e)
        {
            System.out.println("Wrong input");
        }
        
        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println("Array element Unavailable");
        }
        
        catch(Exception e)
        {
            System.out.println("Something wrong..");
        }
        
        finally
        {
        System.out.println("value of n is :"+n1);
        }
    }
}
