/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author souravdewett
 */
public class Day3Interface {
    
    public static void main(String[] args)
    {
        Addition op1 = new Addition();
        op1.display();
        
        counting cn1 = new counting();
        cn1.display();
        
        A a1 = new A();
        a1.display();
        a1.calcMultiplication();
        
        B b1 = new B();
        b1.calcMultiplication();
        b1.calcdivision();
        b1.display();
        
        C c1 = new C();
        c1.display();
    }
    
}
interface Arithmetic
{
    int n1=10;
    int n2=10;
    void display();
    
}

class Addition implements Arithmetic
{
    //int n1 = 20;
    //int n2 = 30;
    @Override
    public void display()
    {
        System.out.println("Sum of n1 and n2 is :" +(n1+n2));
        System.out.println("Inside Addition");
    }
}

class counting extends Addition
{
    
}

interface multiplication extends Arithmetic
{
    void calcMultiplication();
}

class A implements multiplication
{
    public void display()
    {
        System.out.println("n1 =" +n1 + " n2 = "+n2);
        System.out.println("Inside A");
    }
    
    @Override
    public void calcMultiplication()
    {
        System.out.println("Multiplication of n1 and n2 is :" +(n1*n2));
    }
}

interface division extends Arithmetic
{
    public void calcdivision();
}

class B extends Addition implements division,multiplication
{
    @Override 
    public void calcdivision()
    {
        System.out.println("Division is "+(n1/n2));
    }      
    @Override
    public void calcMultiplication()
    {
        System.out.println("Multiplication is "+(n1*n2));
    }
    
    @Override
    public void display()
    {
        System.out.println("Inside Class B");
        System.out.println(n1+n2);
    }
            
}

class C extends B
{
    @Override
    public void display()
    {
        System.out.println(n1%n2);
    }
}