/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
//class always starts with an upper case letter
public class Hello 
{
    public static void main(String[] args)
    {
        int number = 10;
        float percentage;
        char vowel = 'a';
        String firstName = "Sourav";
        System.out.println("Value of Number is:" + number);
        
        percentage = 78.6f;
        System.out.println("Value of percentage is : " + percentage);
        System.out.println("Vowel is = " +vowel);
        System.out.println("Your String is : " + firstName);
        
        vowel = 35;
        number = 'j';
        
        /*
        System.out.println("Vowel" + vowel);
        System.out.println("Value of number" + number + 10);
        System.out.println(1+2 + "test")
        */
        number = 20;
        if(number>10)
        {
           System.out.println("Number is greater");
        }
        else if (number == 10)
        {
            System.out.println("Number is Equal to 10");
        }
        
        switch(number)
        {
            case 10:
                System.out.println("Value = 10");
                break;
                
            case 20:
                System.out.println("Value is 20");
                break;
            
            case 30:
                System.out.println("Value is 30");
                break;
                
            default:
                System.out.println("No Matching Value");
                break;
        }
        
        vowel = 'a';
        switch(vowel)
        {
            case ('a'|'e'|'i'|'o'|'u'):
            /*case 'e':
            case 'i':
            case 'o':
            case 'u':
            */
                System.out.println("It is a Vowel");
                break;
            
            default:
                System.out.println("Not a vowel");
                break;
        }
        
        String province  = "AB";
        switch(province)
        {
            case "ON":
                System.out.println("Ontario");
                break;
                
            case "AB":
                System.out.println("Alberta");
                break;
                
            case "BC":
                System.out.println("British Columbia");
                break;
                
            case "PE":
                System.out.println("Prince Edward");
                break;
                
            default:
                System.out.println("Statement matches none");
                break;
        }
        
        int numbers[] = new int[5];
        int i;
        
        for(i=0; i<numbers.length;i++)
        {
            numbers[i] = (int)(Math.random()*10);
            System.out.println("numbers[" + i + "] =" +numbers[i]);
        }
        
        double PI_Value = Math.PI;
        double power = Math.pow(2,2);
        Math.sqrt(121);
        Math.abs(PI_Value);
        
        float grades[][] = new float [3][4];
        for(i=0;i<3;i++)
        {
            for (int j=0;j<4;j++)
            {
                grades[i][j] = 10.0f;
                System.out.println("Array is " +grades[i][j]);
            }
        }
        
        float randomno;
        for(i=0;i<10;i++)
        {
            randomno = ((int)(Math.random()) * 10);
            System.out.println("no " + (i+1) + " = " + randomno);
            
        }
        
     
        for(i=0;i<=5;i++)
        {
            System.out.println("*");
        }
    }
}
