/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
import java.util.Scanner;

public class Patterns {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of rows in the pyramid (1-9)");
        int noOfRows = sc.nextInt();
        printPattern(noOfRows);

    }
    
    public static void printPattern(int num){
        for(int i = 1; i <= num; i++){
            // this loop will print the spaces after which the pattern has to be printed
            for(int j = 0; j < num - i; j++){
                System.out.print(" * ");
            }
            // this loop will print the *
            for(int k = 0; k < i; k++){
                System.out.print(" * ");
            }
            System.out.println();
        }

    }

}