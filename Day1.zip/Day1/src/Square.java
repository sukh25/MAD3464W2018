/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
import java.util.*;
class Square
{
	public static void main (String[] args) throws java.lang.Exception
	{
	String pattern;
        int noOfTimes;
 
        Scanner scanner = new Scanner(System.in);
 
        System.out.print("Enter the pattern to print : ");
        pattern = scanner.nextLine();
 
        System.out.print("Enter number of times it should get printed : ");
        noOfTimes = scanner.nextInt();
 
        for(int i=1; i<=noOfTimes; i++) {      
 
            System.out.println();
 
            if(i==1 || i==noOfTimes) {
 
                for(int j=1; j<=noOfTimes; j++){
 
                    System.out.print(pattern+" ");
 
                }
            }
            else {
 
                for(int k=1; k<=noOfTimes;k++) {
 
                    if(k==1 || k == noOfTimes) {
 
                        System.out.print(pattern + " ");
 
                    }                   
                    else {
 
                        System.out.print("  ");
 
                    }
                }
            }
        }
	}
}